# ObfPlus

Android Lua editor + obfuscator. Two modes: Edit and Obfuscate.

- Import zip: upload an obfuscation module zip containing APATE/pipeline.lua. Multiple zips supported; spinner selects active.
- Obfuscate: lists steps from APATE/steps.lua, pick steps, set Lua version + seed, run, save output.

## Install on Android (no PC needed)

1. Create GitHub account → new repo → upload **every file** from this folder (including `.github/` and `gradle/`).
2. Go to repo **Actions** tab → run workflow **"build apk"** (or it auto-runs on push).
3. When green, open the run → download artifact **ObfPlus-debug-apk** (zip with `app-debug.apk`).
4. On phone: unzip, tap `app-debug.apk`, allow "install unknown apps" for your files app, install.

Done. App name: ObfPlus. Package: `dev.wreck.obfplus`.

## Local build (Android Studio / CLI)

```bash
./gradlew :app:assembleDebug
# APK → app/build/outputs/apk/debug/app-debug.apk
```

Requires JDK 17+, Android SDK 34.

## Notes

- Runtime: LuaJ 3.0.1 (Lua 5.2). APATE modules targeting pure 5.1 / LuaU may need syntax tweaks.
- No io.popen on Android (seed falls back safely).
- Per-step settings UI not yet present (uses defaults).
