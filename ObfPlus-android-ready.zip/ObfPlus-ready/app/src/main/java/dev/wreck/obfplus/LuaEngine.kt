// kotlin / android / luaj 3.0.1. runs an APATE-style module pipeline inside a sandboxed lua state.
package dev.wreck.obfplus

import org.luaj.vm2.LuaValue
import org.luaj.vm2.lib.jse.JsePlatform
import java.io.File

class LuaEngine(private val root: File) {

    // require() resolves "A.B.C" to <root>/A/B/C.lua, matching the APATE package layout.
    private val bootstrap = """
        local cache = {}
        function require(name)
          if cache[name] ~= nil then return cache[name] end
          local path = ROOT .. "/" .. (name:gsub("%.", "/")) .. ".lua"
          local f = loadfile(path)
          if not f then error("module not found: " .. name .. " (" .. path .. ")", 2) end
          local r = f(name)
          if r == nil then r = true end
          cache[name] = r
          return r
        end
    """.trimIndent()

    // APATE's pipeline calls logger:info / logger:error; the zip does not ship it, so provide one.
    private val loggerShim = """
        local logger = {}
        function logger:info() end
        function logger:warn() end
        function logger:error(msg) error(msg, 0) end
        return logger
    """.trimIndent()

    private fun globals(): org.luaj.vm2.Globals {
        File(root, "logger.lua").let { if (!it.exists()) it.writeText(loggerShim) }
        val g = JsePlatform.standardGlobals()
        g.set("ROOT", LuaValue.valueOf(root.absolutePath))
        g.load(bootstrap, "bootstrap").call()
        return g
    }

    fun listSteps(): List<String> {
        val g = globals()
        val v = g.load(
            """
            local s = require('APATE.steps')
            local t = {}
            for k in pairs(s) do t[#t + 1] = k end
            table.sort(t)
            return table.concat(t, '\n')
            """.trimIndent(), "list_steps"
        ).call()
        return v.tojstring().lines().filter { it.isNotBlank() }
    }

    // steps: names from listSteps(). Per-step settings use APATE defaults in this build.
    fun obfuscate(source: String, steps: List<String>, luaVersion: String, seed: Int): String {
        val g = globals()
        g.set("INPUT", LuaValue.valueOf(source))
        val stepsLua = steps.joinToString(", ") { "{ Name = \"$it\", Settings = {} }" }
        val code = """
            local Pipeline = require("APATE.pipeline")
            local p = Pipeline:fromConfig({
              LuaVersion = "$luaVersion",
              Seed = $seed,
              Steps = { $stepsLua },
            })
            return p:apply(INPUT, "input.lua")
        """.trimIndent()
        return g.load(code, "obfuscate").call().tojstring()
    }
}
