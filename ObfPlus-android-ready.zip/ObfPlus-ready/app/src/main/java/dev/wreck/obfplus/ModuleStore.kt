// kotlin / android. stores imported obfuscation module zips under filesDir/modules.
// a module is valid when its zip contains APATE/pipeline.lua. module root = dir holding APATE/.
package dev.wreck.obfplus

import java.io.File
import java.io.InputStream
import java.util.zip.ZipInputStream

data class LuaModule(val id: String, val root: File)

class ModuleStore(base: File) {
    private val dir = File(base, "modules").apply { mkdirs() }

    fun list(): List<LuaModule> =
        dir.listFiles()?.filter { it.isDirectory }?.mapNotNull { findRoot(it) }?.sortedBy { it.id } ?: emptyList()

    fun importZip(displayName: String, input: InputStream): LuaModule {
        val id = displayName.substringBeforeLast('.').replace(Regex("[^A-Za-z0-9_-]"), "_").ifEmpty { "module" }
        val target = File(dir, id).also { it.deleteRecursively(); it.mkdirs() }
        val canon = target.canonicalPath + File.separator
        ZipInputStream(input).use { zis ->
            generateSequence { zis.nextEntry }.forEach { e ->
                val out = File(target, e.name)
                if (!out.canonicalPath.startsWith(canon)) throw SecurityException("zip entry escapes target: ${e.name}")
                if (e.isDirectory) out.mkdirs() else {
                    out.parentFile?.mkdirs()
                    out.outputStream().use { zis.copyTo(it) }
                }
                zis.closeEntry()
            }
        }
        return findRoot(target) ?: run { target.deleteRecursively(); throw IllegalStateException("no APATE/pipeline.lua in $displayName") }
    }

    private fun findRoot(d: File): LuaModule? {
        val pipeline = d.walkTopDown().firstOrNull { it.name == "pipeline.lua" && it.parentFile?.name == "APATE" } ?: return null
        return LuaModule(d.name, pipeline.parentFile!!.parentFile!!)
    }
}
