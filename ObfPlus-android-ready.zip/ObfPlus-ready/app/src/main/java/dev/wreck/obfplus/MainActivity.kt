// kotlin / android. two modes: Edit (source buffer) and Obfuscate (step picker + run + output).
package dev.wreck.obfplus

import android.graphics.Typeface
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts

class MainActivity : ComponentActivity() {
    private lateinit var store: ModuleStore
    private var modules: List<LuaModule> = emptyList()

    private lateinit var source: EditText
    private lateinit var output: EditText
    private lateinit var moduleSpinner: Spinner
    private lateinit var versionSpinner: Spinner
    private lateinit var seedBox: EditText
    private lateinit var stepList: LinearLayout
    private lateinit var modeTitle: TextView
    private lateinit var editPane: LinearLayout
    private lateinit var obfPane: LinearLayout
    private val stepBoxes = linkedMapOf<String, CheckBox>()
    private var lastOutput = ""

    private val pickModuleZip = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri ?: return@registerForActivityResult
        val name = displayName(uri)
        runCatching { contentResolver.openInputStream(uri)!!.use { store.importZip(name, it) } }
            .onSuccess { toast("imported $name"); reloadModules() }
            .onFailure { toast("import failed: ${it.message}") }
    }

    private val pickSource = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri ?: return@registerForActivityResult
        source.setText(contentResolver.openInputStream(uri)!!.use { it.readBytes().toString(Charsets.UTF_8) })
    }

    private val saveOutput = registerForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        uri ?: return@registerForActivityResult
        contentResolver.openOutputStream(uri)?.use { it.write(lastOutput.toByteArray(Charsets.UTF_8)) }
        toast("saved")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = ModuleStore(filesDir)

        modeTitle = TextView(this).apply { textSize = 18f; typeface = Typeface.DEFAULT_BOLD }
        moduleSpinner = Spinner(this).apply {
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                    modules.getOrNull(pos)?.let { loadSteps(it) }
                }
                override fun onNothingSelected(p: AdapterView<*>?) {}
            }
        }

        source = EditText(this).apply {
            typeface = Typeface.MONOSPACE; gravity = android.view.Gravity.TOP
            hint = "paste or open lua source"
        }
        editPane = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(row(btn("Open .lua") { pickSource.launch(arrayOf("*/*")) }, btn("Clear") { source.setText("") }))
            addView(source, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        }

        versionSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("Lua51", "LuaU"))
        }
        seedBox = EditText(this).apply { hint = "seed (0 = random)"; inputType = android.text.InputType.TYPE_CLASS_NUMBER; setText("0") }
        stepList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        output = EditText(this).apply { typeface = Typeface.MONOSPACE; isFocusable = false; hint = "output" }
        obfPane = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(TextView(this@MainActivity).apply { text = "steps" })
            addView(ScrollView(this@MainActivity).apply { addView(stepList) }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
            addView(row(versionSpinner, seedBox))
            addView(row(btn("Run") { runObfuscate() }, btn("Save output") { saveOutput.launch("output.lua") }))
            addView(output, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1.5f))
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
            addView(modeTitle)
            addView(row(btn("Edit") { setMode("Edit") }, btn("Obfuscate") { setMode("Obfuscate") }))
            addView(row(btn("Import zip") { pickModuleZip.launch(arrayOf("*/*")) }, moduleSpinner))
            addView(editPane, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
            addView(obfPane, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        }
        setContentView(root)
        setMode("Edit")
        reloadModules()
    }

    private fun setMode(m: String) {
        modeTitle.text = "Mode: $m"
        editPane.visibility = if (m == "Edit") View.VISIBLE else View.GONE
        obfPane.visibility = if (m == "Obfuscate") View.VISIBLE else View.GONE
    }

    private fun reloadModules() {
        modules = store.list()
        moduleSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, modules.map { it.id })
        modules.firstOrNull()?.let { loadSteps(it) }
    }

    private fun loadSteps(mod: LuaModule) {
        Thread {
            val res = runCatching { LuaEngine(mod.root).listSteps() }
            runOnUiThread {
                res.onFailure { toast("steps: ${it.message}") }
                res.onSuccess { names ->
                    stepList.removeAllViews(); stepBoxes.clear()
                    names.forEach { n ->
                        val cb = CheckBox(this).apply { text = n }
                        stepList.addView(cb); stepBoxes[n] = cb
                    }
                }
            }
        }.start()
    }

    private fun runObfuscate() {
        val mod = modules.getOrNull(moduleSpinner.selectedItemPosition) ?: return toast("import a module zip first")
        val steps = stepBoxes.filterValues { it.isChecked }.keys.toList()
        val version = versionSpinner.selectedItem as String
        val seed = seedBox.text.toString().toIntOrNull() ?: 0
        val src = source.text.toString()
        output.setText("working...")
        Thread {
            val res = runCatching { LuaEngine(mod.root).obfuscate(src, steps, version, seed) }
            runOnUiThread {
                res.onSuccess { lastOutput = it; output.setText(it) }
                    .onFailure { lastOutput = ""; output.setText("error: ${it.message}") }
            }
        }.start()
    }

    private fun row(vararg views: View) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        views.forEach { addView(it, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)) }
    }

    private fun btn(text: String, onClick: () -> Unit) = Button(this).apply {
        this.text = text; setOnClickListener { onClick() }
    }

    private fun displayName(uri: android.net.Uri): String =
        contentResolver.query(uri, null, null, null, null)?.use { c ->
            val i = c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
            if (c.moveToFirst() && i >= 0) c.getString(i) else null
        } ?: "module.zip"

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
