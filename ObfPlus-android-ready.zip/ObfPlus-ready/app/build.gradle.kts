plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "dev.wreck.obfplus"
    compileSdk = 34
    defaultConfig {
        applicationId = "dev.wreck.obfplus"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "0.1"
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation("org.luaj:luaj-jse:3.0.1")
    implementation("androidx.activity:activity-ktx:1.9.3")
}
